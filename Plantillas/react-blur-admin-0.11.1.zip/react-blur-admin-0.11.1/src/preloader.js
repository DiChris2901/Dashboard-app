import React from 'react';

export class Preloader extends React.Component {
  render() {
    return (
      <div className='preloader-component-container'>
        <div className="preloader-component">
          <div>
          </div>
        </div>
      </div>
    );
  }
}
