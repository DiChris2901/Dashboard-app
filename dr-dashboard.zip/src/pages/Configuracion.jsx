import React from "react";

const Configuracion = () => {
  return (
    <div>
      <h2>Configuración (en construcción)</h2>
    </div>
  );
};

export default Configuracion;
